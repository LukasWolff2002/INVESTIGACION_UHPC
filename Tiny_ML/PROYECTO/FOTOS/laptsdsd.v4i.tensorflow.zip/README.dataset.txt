# laptsdsd > 2024-05-20 7:59pm
https://universe.roboflow.com/cards-mawhv/laptsdsd

Provided by a Roboflow user
License: CC BY 4.0


# Duck > 2023-05-08 8:24pm
https://universe.roboflow.com/assignment-ck4vo/duck-iokd3

Provided by a Roboflow user
License: CC BY 4.0


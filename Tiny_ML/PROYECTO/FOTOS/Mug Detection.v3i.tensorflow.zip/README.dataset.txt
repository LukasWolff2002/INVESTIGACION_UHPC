# Mug Detection > 2024-05-22 5:44pm
https://universe.roboflow.com/noe-ew9vt/mug-detection-k5qpd

Provided by a Roboflow user
License: CC BY 4.0

